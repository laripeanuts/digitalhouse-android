class Cliente(val nome: String, sobrenome: String) {
}