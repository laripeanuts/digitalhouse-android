class Turma(val nome: String, curso: Curso) {
}