class Aula(val materia: Materia, var horarioInicio: String, var horarioFim: String) {
}