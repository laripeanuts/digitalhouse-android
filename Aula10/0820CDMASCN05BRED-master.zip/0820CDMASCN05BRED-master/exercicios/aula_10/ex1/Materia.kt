class Materia(val nome: String) {
}