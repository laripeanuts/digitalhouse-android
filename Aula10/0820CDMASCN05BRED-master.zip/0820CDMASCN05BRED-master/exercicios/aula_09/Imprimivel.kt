interface Imprimivel {
    fun mostrarDados()
}