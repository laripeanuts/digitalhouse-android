import kotlin.math.pow;

// Constante, não pode ser alterado no código e tem que estar fora dos métodos
const IDADE_MAXIMA = 18

fun main(args: Array<String>) {
    val corDoSemaforo = IDADE_MAXIMA // verde (siga!), vermelho (pare!), amarelo (pare)
    
    if (idade >= IDADE_MAXIMA) {
        println("É de maior")
    } else {
        println("É de menor")
    }
}
}